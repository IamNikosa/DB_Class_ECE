-- Generated INSERT statements for Festival table
INSERT INTO Festival (Name, Start_Date, End_Date, Location_ID) VALUES
('Into Festival', '2018-07-14', '2018-07-15', 1),
('Just Festival', '2019-08-28', '2019-09-10', 2),
('Purpose Festival', '2020-06-09', '2020-09-13', 3),
('Enter Festival', '2021-06-09', '2021-07-11', 4),
('Care Festival', '2022-06-16', '2022-07-18', 5),
('Believe Festival', '2023-07-04', '2023-07-26', 6),
('Middle Festival', '2024-08-18', '2024-09-16', 7),
('Her Festival', '2025-08-30', '2025-09-01', 8),
('Property Festival', '2026-06-17', '2026-07-19', 9),
('Once Festival', '2027-07-16', '2027-08-11', 10);
