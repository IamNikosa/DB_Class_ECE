-- Generated INSERT statements for Festival table
INSERT INTO Festival (Name, Start_Date, End_Date, Location_ID) VALUES
('Wrong Festival', '2018-08-14', '2018-09-13', 1),
('Cold Festival', '2019-08-09', '2019-08-29', 2),
('Decide Festival', '2020-08-18', '2020-08-31', 3),
('Visit Festival', '2021-07-19', '2021-09-17', 4),
('Nearly Festival', '2022-06-03', '2022-06-21', 5),
('Lot Festival', '2023-07-21', '2023-09-23', 6),
('At Festival', '2024-06-25', '2024-07-23', 7),
('Social Festival', '2025-08-20', '2025-08-24', 8),
('Hospital Festival', '2026-08-12', '2026-09-20', 9),
('Even Festival', '2027-08-03', '2027-08-29', 10);
