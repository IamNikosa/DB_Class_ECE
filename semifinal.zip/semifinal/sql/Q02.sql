SELECT 
    pe.ID AS Performer_ID,
    pe.Stage_Name,
    IF(COUNT(pf.ID) > 0, 'YES', 'NO') AS Participated
FROM Genre g
JOIN Subgenre sg ON sg.Genre_ID = g.ID
JOIN Performer_Subgenre ps ON ps.Subgenre_ID = sg.ID
JOIN Performer pe ON ps.Performer_ID = pe.ID
LEFT JOIN Performance pf ON pf.Performer_ID = pe.ID
LEFT JOIN Event e ON pf.Event_ID = e.ID
LEFT JOIN Festival f ON e.Festival_ID = f.ID AND f.Year = '2024'
WHERE g.Name = 'Indie'
GROUP BY pe.ID;