SELECT DISTINCT s.ID, s.Name
FROM Support_Staff ss
JOIN Staff s ON ss.Staff_ID = s.ID
LEFT JOIN event_staff es ON s.ID = es.Staff_ID
LEFT JOIN Event e ON es.Event_ID = e.ID AND DATE(e.Start_Time) = '2020-10-10'
WHERE e.ID IS NULL;