SELECT 
    e.ID AS Event_ID,
    f.Name AS Festival_Name,
    e.Start_Time,
    AVG(r.Interpretation + r.Sound + r.Lighting + r.Stage_Presence + r.Organization + r.Overall) AS Avg_Overall_Score
FROM Spectator sp
JOIN Ticket t ON sp.Ticket_ID = t.ID
JOIN Event e ON t.Event_ID = e.ID
JOIN Festival f ON e.Festival_ID = f.ID
JOIN Review r ON r.Ticket_ID = t.ID
WHERE sp.Visitor_ID = 267
GROUP BY e.ID
ORDER BY e.Start_Time;