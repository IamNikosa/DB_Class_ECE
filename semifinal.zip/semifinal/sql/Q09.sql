SELECT 
    Year,
    View_Count,
    GROUP_CONCAT(Visitor_ID) AS Visitors
FROM (
    SELECT 
        sp.Visitor_ID,
        f.Year,
        COUNT(DISTINCT e.ID) AS View_Count
    FROM Spectator sp
    JOIN Ticket t ON sp.Ticket_ID = t.ID
    JOIN Event e ON t.Event_ID = e.ID
    JOIN Festival f ON e.Festival_ID = f.ID
    GROUP BY sp.Visitor_ID, f.Year
    HAVING View_Count > 3
) AS yearly_counts
GROUP BY Year, View_Count
HAVING COUNT(*) > 1;