SELECT 
    pe.ID AS Performer_ID,
    pe.Stage_Name,
    AVG(r.Interpretation) AS Avg_Interpretation,
    AVG(r.Overall) AS Avg_Overall
FROM Performer pe
JOIN Performance p FORCE INDEX (idx_performance_performer) ON pe.ID = p.Performer_ID
JOIN Event e FORCE INDEX (PRIMARY) ON e.ID = p.Event_ID
JOIN Ticket t FORCE INDEX (idx_ticket_event) ON e.ID = t.Event_ID
JOIN Review r FORCE INDEX (idx_review_ticket) ON t.ID = r.Ticket_ID 
WHERE pe.Stage_Name = 'Rich Band'
GROUP BY pe.ID;