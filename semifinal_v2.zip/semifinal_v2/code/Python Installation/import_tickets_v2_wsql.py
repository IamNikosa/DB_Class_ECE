#!/usr/bin/env python3
"""
generate_tickets.py

Generates tickets for each event in the `Festival` database,
writes them to the database, and also outputs all INSERT
statements to `generated_tickets.sql`.
"""
import os
import random
import mysql.connector
from faker import Faker
from datetime import datetime

# ---------------- CONFIG ----------------
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'Festival'
}
SQL_FILENAME = 'generated_tickets.sql'

# ---------------- SETUP ----------------
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)
conn = mysql.connector.connect(**DB_CONFIG)
cursor = conn.cursor()

fake = Faker()
Faker.seed(123)
random.seed(123)

# ---------------- EAN-13 GENERATION ----------------
def calculate_ean13_check_digit(ean12):
    if len(ean12) != 12 or not ean12.isdigit():
        raise ValueError("Input must be a 12-digit numeric string.")
    total = 0
    for i, digit in enumerate(ean12):
        num = int(digit)
        total += num * 3 if (i + 1) % 2 == 0 else num
    return str((10 - (total % 10)) % 10)

def generate_ean13(ticket_id):
    prefix = '200'
    company_code = '0001'
    product_code = str(ticket_id).zfill(5)
    ean12 = prefix + company_code + product_code
    return ean12 + calculate_ean13_check_digit(ean12)

# ---------------- FETCH EVENTS ----------------
def fetch_events_with_capacity():
    cursor.execute(
        """
        SELECT e.ID, s.Capacity
        FROM Event e
        JOIN Stage s ON e.Stage_ID = s.ID
        """
    )
    return cursor.fetchall()

events = fetch_events_with_capacity()
if not events:
    print("Ensure that Event table is populated.")
    conn.close()
    exit()

# Default pricing
pricing = {'Student': 20.00, 'Standard': 50.00, 'Backstage': 80.00, 'VIP': 120.00}
types = list(pricing.keys())

# Collect SQL statements for file
sql_statements = []

# ---------------- GENERATE & INSERT TICKETS ----------------
for event_id, capacity in events:
    for _ in range(capacity):
        stage_info = f"Entrance: Gate {random.randint(1,5)}, Row {random.randint(1,30)}"
        safe_stage = stage_info.replace("'", "''")
        activated = False
        date_bought = None
        payment_id = None
        type_choices = types.copy()

        while type_choices:
            ticket_type = random.choice(type_choices)
            price = pricing[ticket_type]
            try:
                cursor.execute(
                    """
                    INSERT INTO Ticket
                      (EAN_CODE, Stage_Info, Price, Activated, Date_Bought, Type_ID, Payment_ID, Event_ID)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    ('', stage_info, price, activated, date_bought, ticket_type, payment_id, event_id)
                )
                ticket_id = cursor.lastrowid
                ean = generate_ean13(ticket_id)
                cursor.execute(
                    "UPDATE Ticket SET EAN_CODE = %s WHERE ID = %s",
                    (ean, ticket_id)
                )
                conn.commit()

                # prepare SQL for file
                val_date = f"'{date_bought}'" if date_bought else 'NULL'
                val_pay = f"'{payment_id}'" if payment_id else 'NULL'
                insert_sql = (
                    f"INSERT INTO Ticket (EAN_CODE,Stage_Info,Price,Activated,Date_Bought,Type_ID,Payment_ID,Event_ID) "
                    f"VALUES ('{ean}','{safe_stage}',{price},{int(activated)},{val_date},"  
                    f"'{ticket_type}',{val_pay},{event_id});"
                )
                sql_statements.append(insert_sql)
                break
            except mysql.connector.Error as err:
                if 'VIP ticket limit' in str(err):
                    type_choices = [t for t in type_choices if t != 'VIP']
                    continue
                print(f"Error inserting ticket: {err}")
                break

# ---------------- WRITE .SQL FILE ----------------
with open(SQL_FILENAME, 'w', encoding='utf-8') as f:
    f.write('-- Generated INSERTs for Ticket table\n')
    for stmt in sql_statements:
        f.write(stmt + '\n')

# ---------------- CLEANUP ----------------
cursor.close()
conn.close()
print("Ticket generation complete, SQL written to", SQL_FILENAME)
