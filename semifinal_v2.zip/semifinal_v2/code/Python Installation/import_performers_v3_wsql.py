#!/usr/bin/env python3
"""
import_performers.py

Generates fake performers and band memberships, inserts into the Performer and Membership
Tables, and writes corresponding INSERT statements into a .sql file in the same directory.
Ensures every band has at least two members by controlling the ratio of solo artists to bands.
"""
import os
import random
import mysql.connector
from faker import Faker
from datetime import datetime

# ---------------- SETUP ----------------
# Ensure script runs from its own directory
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# ---------------- CONFIG ----------------
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # adjust if needed
    'database': 'festival'
}
SQL_FILENAME = 'generated_performers_and_memberships.sql'
NUM_PERFORMERS = 80

# ---------------- CONNECT ----------------
conn = mysql.connector.connect(**DB_CONFIG)
cursor = conn.cursor()

# ---------------- GENERATE DATA ----------------
fake = Faker()
seed_val = int(datetime.now().timestamp())
Faker.seed(seed_val)
random.seed(seed_val)

# Determine number of bands so solos >= 2 * bands
max_bands = NUM_PERFORMERS // 3  # ensures solos >= 2*bands
band_count = random.randint(1, max_bands) if max_bands >= 1 else 0
solo_count = NUM_PERFORMERS - band_count

# Prepare flags and shuffle order
is_band_flags = [True] * band_count + [False] * solo_count
random.shuffle(is_band_flags)

performers = []
bands = []
solo_artists = []
memberships = []

# Create performers list and separate bands vs solos based on flags
for i, flag in enumerate(is_band_flags, start=1):
    is_band = flag
    real_name = fake.name().replace("'", "''") if not is_band else None
    stage_name = fake.word().capitalize() + (" Band" if is_band else " Artist")
    stage_name = stage_name.replace("'", "''")
    birthday = fake.date_of_birth(minimum_age=18, maximum_age=60) if not is_band else None
    formation_date = fake.date_between(start_date='-30y', end_date='-1y') if is_band else None
    instagram = fake.user_name().replace("'", "''")
    website = fake.url().replace("'", "''")

    performers.append((
        i, real_name, stage_name, birthday,
        instagram, website, int(is_band), formation_date
    ))

    if is_band:
        bands.append(i)
    else:
        solo_artists.append(i)

# Copy solos for controlled assignment
available_solo = solo_artists.copy()

# Ensure each band has at least two members
for band_id in bands:
    for _ in range(2):
        artist_id = available_solo.pop(0)
        join_date = fake.date_between(start_date='-10y', end_date='today')
        memberships.append((band_id, artist_id, join_date))

# Assign remaining solos randomly to bands (60% chance)
for artist_id in available_solo:
    if random.random() < 0.6:
        band_id = random.choice(bands)
        join_date = fake.date_between(start_date='-10y', end_date='today')
        memberships.append((band_id, artist_id, join_date))

# ---------------- INSERT INTO DB ----------------
insert_perf_sql = (
    "INSERT INTO Performer "
    "(ID, Real_Name, Stage_Name, Birthday, Instagram, Website, Is_Band, Formation_Date) "
    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
)
cursor.executemany(insert_perf_sql, performers)
conn.commit()
print(f"Inserted {cursor.rowcount} performers into the database.")

if memberships:
    insert_mem_sql = (
        "INSERT INTO Membership (Band_ID, Artist_ID, Join_Date) VALUES (%s, %s, %s)"
    )
    cursor.executemany(insert_mem_sql, memberships)
    conn.commit()
    print(f"Inserted {cursor.rowcount} membership rows into the database.")

# ---------------- WRITE .SQL FILE ----------------
def write_sql_file(performers, memberships, filename):
    filepath = os.path.join(script_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('-- Generated INSERTs for Performer table\n')
        for p in performers:
            id_, real, stage, bday, insta, web, isb, form = p
            vals = [
                str(id_),
                f"'{real}'" if real else 'NULL',
                f"'{stage}'",
                f"'{bday}'" if bday else 'NULL',
                f"'{insta}'",
                f"'{web}'",
                str(isb),
                f"'{form}'" if form else 'NULL'
            ]
            f.write(
                "INSERT INTO Performer (ID, Real_Name, Stage_Name, Birthday, Instagram, Website, Is_Band, Formation_Date) "
                f"VALUES ({', '.join(vals)});\n"
            )
        if memberships:
            f.write('\n-- Generated INSERTs for Membership table\n')
            for m in memberships:
                f.write(
                    f"INSERT INTO Membership (Band_ID, Artist_ID, Join_Date) VALUES ({m[0]}, {m[1]}, '{m[2]}');\n"
                )

write_sql_file(performers, memberships, SQL_FILENAME)

# ---------------- CLEANUP ----------------
cursor.close()
conn.close()
print("Database connection closed.")
