SELECT 
    DATE(e.Start_Time) AS Festival_Date,
    CEIL(COUNT(sp.Visitor_ID) * 0.05) AS Required_Security,
    CEIL(COUNT(sp.Visitor_ID) * 0.02) AS Required_Support,
    CEIL(COUNT(sp.Visitor_ID) * 0.03) AS Required_Technical
FROM Event e
JOIN Ticket t ON e.ID = t.Event_ID
JOIN Spectator sp ON sp.Ticket_ID = t.ID
GROUP BY DATE(e.Start_Time)
ORDER BY Festival_Date;