SELECT 
    f.Year,
    COALESCE(p.Name, 'ΣΥΝΟΛΟ') AS Τρόπος_Πληρωμής,
    SUM(t.Price) AS Έσοδα
FROM Transaction tr
JOIN Ticket t ON tr.Ticket_ID = t.ID
JOIN Event e ON t.Event_ID = e.ID
JOIN Festival f ON e.Festival_ID = f.ID
JOIN Type tp ON t.Type_ID = tp.Name
LEFT JOIN Payment p ON tr.Payment_ID = p.Name
WHERE tr.Is_Resale = FALSE
GROUP BY f.Year, p.Name WITH ROLLUP
HAVING NOT (f.Year IS NULL)  -- exclude grand total