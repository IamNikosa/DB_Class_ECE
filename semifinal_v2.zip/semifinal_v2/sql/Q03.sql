SELECT 
    p.Performer_ID,
    pe.Real_Name,
    pe.Stage_Name,
    f.ID AS Festival_ID,
    f.Name AS Festival_Name,
    COUNT(*) AS WarmUp_Count
FROM Performance p
JOIN Event e ON p.Event_ID = e.ID
JOIN Festival f ON e.Festival_ID = f.ID
JOIN Performer pe ON p.Performer_ID = pe.ID
WHERE p.Type = 'Warm up'
GROUP BY p.Performer_ID, f.ID
HAVING COUNT(*) > 2;