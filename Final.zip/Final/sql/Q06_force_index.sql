SELECT 
    e.ID AS Event_ID,
    f.Name AS Festival_Name,
    e.Start_Time,
    AVG(r.Interpretation + r.Sound + r.Lighting + r.Stage_Presence + r.Organization + r.Overall) AS Avg_Overall_Score
FROM Spectator sp FORCE INDEX (idx_visitor_ticket)
JOIN Ticket t FORCE INDEX (PRIMARY) ON t.ID = sp.Ticket_ID 
JOIN Event e FORCE INDEX (PRIMARY) ON e.ID = t.Event_ID 
JOIN Festival f FORCE INDEX (PRIMARY) ON f.ID = e.Festival_ID 
JOIN Review r FORCE INDEX (idx_review_ticket) ON t.ID = r.Ticket_ID 
WHERE sp.Visitor_ID = 267
GROUP BY e.ID
ORDER BY e.Start_Time;