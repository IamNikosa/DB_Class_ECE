SELECT 
    f.ID AS Festival_ID,
    f.Name AS Festival_Name,
    AVG(
        CASE s.Type
            WHEN 'Trainee' THEN 1
            WHEN 'Beginner' THEN 2
            WHEN 'Intermediate' THEN 3
            WHEN 'Experienced' THEN 4
            WHEN 'Very Experienced' THEN 5
        END
    ) AS Avg_Experience_Level
FROM Festival f
JOIN Event e ON f.ID = e.Festival_ID
JOIN event_staff es ON es.Event_ID = e.ID
JOIN Technical_Staff ts ON es.Staff_ID = ts.Staff_ID
JOIN Staff s ON ts.Staff_ID = s.ID
GROUP BY f.ID
ORDER BY Avg_Experience_Level ASC
LIMIT 1;