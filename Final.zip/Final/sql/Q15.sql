SELECT 
    v.First_Name,
    v.Last_Name,
    pe.Stage_Name,
    SUM(r.Overall) AS Total_Score
FROM Review r
JOIN Ticket t ON r.Ticket_ID = t.ID
JOIN Spectator sp ON sp.Ticket_ID = t.ID
JOIN Visitor v ON v.ID = sp.Visitor_ID
JOIN Event e ON t.Event_ID = e.ID
JOIN Performance p ON e.ID = p.Event_ID
JOIN Performer pe ON pe.ID = p.Performer_ID
WHERE t.Activated = TRUE
GROUP BY v.ID, pe.ID
ORDER BY Total_Score DESC
LIMIT 5;