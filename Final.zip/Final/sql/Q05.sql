SELECT 
    pe.ID AS Performer_ID,
    pe.Stage_Name,
    TIMESTAMPDIFF(YEAR, pe.Birthday, CURDATE()) AS Age,
    COUNT(DISTINCT f.ID) AS Festival_Count
FROM Performer pe
JOIN Performance p ON pe.ID = p.Performer_ID
JOIN Event e ON p.Event_ID = e.ID
JOIN Festival f ON e.Festival_ID = f.ID
WHERE pe.Is_Band = FALSE
  AND TIMESTAMPDIFF(YEAR, pe.Birthday, CURDATE()) < 30
GROUP BY pe.ID
ORDER BY Festival_Count DESC;