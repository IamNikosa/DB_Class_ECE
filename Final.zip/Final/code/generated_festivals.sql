-- Generated INSERT statements for Festival table
INSERT INTO Festival (Name, Start_Date, End_Date, Location_ID) VALUES
('Become Festival', '2018-07-08', '2018-08-21', 1),
('Feeling Festival', '2019-07-01', '2019-07-09', 2),
('Church Festival', '2020-06-05', '2020-09-24', 3),
('Set Festival', '2021-06-24', '2021-07-14', 4),
('Perhaps Festival', '2022-08-23', '2022-09-20', 5),
('Significant Festival', '2023-07-09', '2023-09-09', 6),
('Large Festival', '2024-08-22', '2024-09-06', 7),
('Despite Festival', '2025-06-26', '2025-09-12', 8),
('Firm Festival', '2026-08-07', '2026-09-29', 9),
('Traditional Festival', '2027-08-18', '2027-09-02', 10);
