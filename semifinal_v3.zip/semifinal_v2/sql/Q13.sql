SELECT 
    pe.ID AS Performer_ID,
    pe.Stage_Name,
    COUNT(DISTINCT l.Continent) AS Continents_Performed
FROM Performer pe
JOIN Performance p ON pe.ID = p.Performer_ID
JOIN Event e ON p.Event_ID = e.ID
JOIN Festival f ON e.Festival_ID = f.ID
JOIN Location l ON f.Location_ID = l.ID
GROUP BY pe.ID
HAVING COUNT(DISTINCT l.Continent) >= 3
ORDER BY Continents_Performed DESC;