
WITH  
-- (same seed CTEs as before…)  
visitor_reviews AS (
  SELECT r.ID AS review_id, r.Overall AS score, t.Event_ID AS event_id
  FROM Spectator sp
  JOIN Ticket t    ON sp.Ticket_ID = t.ID
  JOIN Review r    ON r.Ticket_ID = t.ID
  WHERE sp.Visitor_ID = 276
),
top_reviews AS (
  SELECT event_id
  FROM (
    SELECT event_id, score,
      ROW_NUMBER() OVER (ORDER BY score DESC) AS rn
    FROM visitor_reviews
  ) x
  WHERE rn <= 3
),
top_performers AS (
  SELECT DISTINCT Performer_ID
  FROM Performance
  WHERE Event_ID IN (SELECT event_id FROM top_reviews)
),
top_bands AS (
  SELECT DISTINCT Band_ID AS Performer_ID
  FROM Membership
  WHERE Artist_ID IN (SELECT Performer_ID FROM top_performers)
),
seed_performers AS (
  SELECT Performer_ID FROM top_performers
  UNION
  SELECT Performer_ID FROM top_bands
),
seed_subgenres AS (
  SELECT Subgenre_ID
  FROM Performer_Subgenre
  WHERE Performer_ID IN (SELECT Performer_ID FROM seed_performers)
),
all_similar AS (
  SELECT Performer_ID FROM seed_performers
  UNION
  SELECT Performer_ID
  FROM Performer_Subgenre
  WHERE Subgenre_ID IN (SELECT Subgenre_ID FROM seed_subgenres)
),

-- now compute overlaps per event:
event_scores AS (
  SELECT
    e.ID                 AS event_id,
    f.Name               AS festival_name,
    e.Start_Time,
    s.Name               AS stage_name,
    -- how many seed performers/bands are on this event?
    COUNT(DISTINCT CASE
      WHEN p.Performer_ID IN (SELECT Performer_ID FROM seed_performers)
      THEN p.Performer_ID
    END)                  AS perf_matches,
    -- how many seed subgenres appear via the performers on this event?
    COUNT(DISTINCT CASE
      WHEN ps.Subgenre_ID IN (SELECT Subgenre_ID FROM seed_subgenres)
      THEN ps.Subgenre_ID
    END)                  AS subgenre_matches
  FROM Performance p
  JOIN Event           e  ON p.Event_ID = e.ID
  JOIN Festival        f  ON e.Festival_ID = f.ID
  JOIN Stage           s  ON e.Stage_ID = s.ID
  LEFT JOIN Performer_Subgenre ps
    ON ps.Performer_ID = p.Performer_ID
  WHERE p.Performer_ID IN (SELECT Performer_ID FROM all_similar)
    AND e.ID NOT IN (SELECT event_id FROM visitor_reviews)
  GROUP BY e.ID, f.Name, e.Start_Time, s.Name
)

SELECT
  event_id,
  festival_name,
  stage_name,
  Start_Time,
  perf_matches,
  subgenre_matches,
  (perf_matches + subgenre_matches) AS total_score
FROM event_scores
ORDER BY total_score DESC, perf_matches DESC, subgenre_matches DESC, Start_Time
LIMIT 15;
