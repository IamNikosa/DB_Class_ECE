-- Generated INSERTs for Payment and Type tables
INSERT INTO Payment (Name) VALUES ('Credit Card');
INSERT INTO Payment (Name) VALUES ('PayPal');
INSERT INTO Payment (Name) VALUES ('Cash');
INSERT INTO Payment (Name) VALUES ('Bank Transfer');

INSERT INTO Type (Name) VALUES ('VIP');
INSERT INTO Type (Name) VALUES ('Standard');
INSERT INTO Type (Name) VALUES ('Student');
INSERT INTO Type (Name) VALUES ('Backstage');
